#! /bin/sh 
# $Id$

# To restart from scratch use: autoreconf --install
autoreconf -s -i -m -f
